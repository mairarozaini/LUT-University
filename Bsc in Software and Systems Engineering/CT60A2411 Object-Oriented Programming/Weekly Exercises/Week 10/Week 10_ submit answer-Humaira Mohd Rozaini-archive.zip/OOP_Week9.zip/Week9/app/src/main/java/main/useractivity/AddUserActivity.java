package main.useractivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddUserActivity extends AppCompatActivity {

    UserStorage user_list;
    RadioButton SE;
    RadioButton IM;
    RadioButton CE;
    RadioButton EE;
    EditText name;
    EditText lastname;
    EditText email;

    CheckBox bc_dgr;
    CheckBox mst_dgr;
    CheckBox lci_dgr;
    CheckBox phd_dgr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        user_list = UserStorage.getInstance();
        SE = findViewById(R.id.seRadioButton);
        IM = findViewById(R.id.imRadioButton);
        CE = findViewById(R.id.ceRadioButton);
        EE = findViewById(R.id.eeRadioButton);
        name = findViewById(R.id.editFirstName);
        lastname = findViewById(R.id.editLastName);
        email = findViewById(R.id.editEmail);
        bc_dgr = findViewById(R.id.bcCheckBox);
        mst_dgr = findViewById(R.id.msCheckBox);
        lci_dgr = findViewById(R.id.lciCheckBox);
        phd_dgr = findViewById(R.id.phdCheckBox);
    }

    public void adduser(View view)
    {
        String userDegrees = "";
        if(bc_dgr.isChecked())
        {
            userDegrees += "B.Sc degree ";
        }
        if(mst_dgr.isChecked())
        {
            userDegrees += "M.Sc. degree ";
        }
        if(lci_dgr.isChecked())
        {
            userDegrees += "Lic. degree ";
        }
        if(phd_dgr.isChecked())
        {
            userDegrees += "Ph.D. degree ";
        }
        if(SE.isChecked())
        {
            user_list.addUser(new User(name.getText().toString(), lastname.getText().toString(), email.getText().toString(), SE.getText().toString(), userDegrees));
        }
        else if (IM.isChecked())
        {
            user_list.addUser(new User(name.getText().toString(), lastname.getText().toString(), email.getText().toString(), IM.getText().toString(), userDegrees));
        }
        else if (CE.isChecked())
        {
            user_list.addUser(new User(name.getText().toString(), lastname.getText().toString(), email.getText().toString(), CE.getText().toString(), userDegrees));
        }
        else if(EE.isChecked())
        {
            user_list.addUser(new User(name.getText().toString(), lastname.getText().toString(), email.getText().toString(), EE.getText().toString(), userDegrees));
        }
        Context context = AddUserActivity.this;
        user_list.saveFile(context);
    }
    public void return_click(View v)
    {
        Intent intent = new Intent(AddUserActivity.this, MainActivity.class);
        startActivity(intent);
    }
}