package main.useractivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button add_user = (Button) findViewById(R.id.button_AddUserActivity);
        UserStorage userStorage = UserStorage.getInstance();
        Context context = MainActivity.this;
        userStorage.loadFile(context);
        add_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add_user_page = new Intent(MainActivity.this, AddUserActivity.class);
                startActivity(add_user_page);
            }
        });
        Button viewusers = (Button) findViewById(R.id.viewusers_button);
        viewusers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListUserActivity.class);
                startActivity(intent);
            }
        });
    }


}