package main.useractivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserListAdapter extends RecyclerView.Adapter<UserViewHolder> {

    Context context;
    List<User> users;

    public UserListAdapter(Context context, List<User> users)
    {
        this.users = users;
        this.context = context;
    }
    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new UserViewHolder(LayoutInflater.from(context).inflate(R.layout.itemview, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.name.setText(users.get(position).getFirstName());
        holder.lastname.setText(users.get(position).getLastName());
        holder.email.setText(users.get(position).getEmail());
        holder.degree.setText(users.get(position).getDegreeProgram());
        holder.degree_Level.setText(users.get(position).getDegreeLevel());
    }

    @Override
    public int getItemCount() {
        return users.size();
    }
}
