package main.useractivity;

import android.content.Context;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class UserStorage {
    private static UserStorage storage = null;
    private UserStorage()
    {

    }
    ArrayList<User> users = new ArrayList<>();
    public ArrayList<User> getUsers()
    {
        return users;
    }
    public void addUser(User user)
    {
        users.add(user);
    }
    public void saveFile(Context context)
    {
        try{
            ObjectOutputStream userWriter = new ObjectOutputStream( context.openFileOutput("users.data", Context.MODE_PRIVATE));
            userWriter.writeObject(users);
            userWriter.close();
        }
        catch (IOException e)
        {
            System.out.println("Saving users failed");
            e.printStackTrace();
        }
    }
    public void loadFile(Context context)
    {
        try{
            ObjectInputStream userReader = new ObjectInputStream(context.openFileInput("users.data"));
            users = (ArrayList<User>) userReader.readObject();
            userReader.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Loading was unsuccessful");
            e.printStackTrace();
        }
        catch (IOException e)
        {
            System.out.println("Loading was unsuccessful");
            e.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            System.out.println("Loading was unsuccessful");
            e.printStackTrace();
        }
    }
    public static UserStorage getInstance()
    {
        if(storage == null)
        {
            storage = new UserStorage();
        }
        return storage;
    }
}
