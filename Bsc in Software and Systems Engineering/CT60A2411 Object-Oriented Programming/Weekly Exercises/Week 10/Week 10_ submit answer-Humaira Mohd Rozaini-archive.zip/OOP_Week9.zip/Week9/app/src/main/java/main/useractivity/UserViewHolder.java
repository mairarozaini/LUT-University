package main.useractivity;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class UserViewHolder extends RecyclerView.ViewHolder {
    TextView name, lastname, email, degree, degree_Level;
    public UserViewHolder(@NonNull View item_View)
    {
        super(item_View);
        name = item_View.findViewById(R.id.textFirstName);
        lastname = item_View.findViewById(R.id.textLastName);
        email = item_View.findViewById(R.id.textEmail);
        degree = item_View.findViewById(R.id.textDegreeProgram);
        degree_Level = item_View.findViewById(R.id.textUserDegrees);
    }
}

