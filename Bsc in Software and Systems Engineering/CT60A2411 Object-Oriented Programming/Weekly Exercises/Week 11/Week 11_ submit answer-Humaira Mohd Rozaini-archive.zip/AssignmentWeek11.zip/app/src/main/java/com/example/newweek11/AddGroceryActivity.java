package com.example.newweek11;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddGroceryActivity extends AppCompatActivity {
    public EditText editGroceryname, editgrocerynote;
    public Button buttonAddGrocery;

    public Grocery grocery;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_grocery);
        editGroceryname = findViewById(R.id.editGroceryName);
        editgrocerynote = findViewById(R.id.editGroceryNote);
        buttonAddGrocery = findViewById(R.id.buttonAddGrocery);
        long timestamp = Calendar.getInstance().getTimeInMillis();
            buttonAddGrocery.setOnClickListener(v -> {
                grocery = new Grocery(editGroceryname.getText().toString(),editgrocerynote.getText().toString(),timestamp);
                ListGrocery.getInstance().addGrocery(grocery);
                MainActivity.adapter.notifyDataSetChanged();
                finish();
            });
        }
    }