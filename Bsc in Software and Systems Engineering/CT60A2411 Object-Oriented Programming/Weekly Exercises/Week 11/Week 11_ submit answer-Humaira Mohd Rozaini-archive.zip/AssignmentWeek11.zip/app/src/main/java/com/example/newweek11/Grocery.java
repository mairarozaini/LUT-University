package com.example.newweek11;

public class Grocery {

    public String name;
    public String note;
    public long timestamp;
    public Grocery(String name, String note, long timestamp){
        this.name = name;
        this.note = note;
        this.timestamp = timestamp;
    }

    public String getName(){
        return name;
    }

    public long getTimestamp(){
        return timestamp;
    }

    public String getNote(){
        return note;
    }

    public void setNote(String note){
        this.note = note;
    }

    public void setName(String name){
        this.name = name;
    }
}
