package com.example.newweek11;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class GroceryListAdapter extends RecyclerView.Adapter<GroceryViewHolder> {

    private Context context;
    public ArrayList<Grocery> groceries = new ArrayList<>();

    public GroceryListAdapter(Context context, ArrayList<Grocery> groceries) {
        this.context = context;
        this.groceries = groceries;
    }

    @NonNull
    @Override
    public GroceryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new GroceryViewHolder(LayoutInflater.from(context).inflate(R.layout.item_grocery, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull GroceryViewHolder holder, int position) {
        Grocery grocery = groceries.get(position);
        holder.textGroceryName.setText(groceries.get(position).getName());
        holder.textGroceryNote.setText(groceries.get(position).getNote());

        holder.imageEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.textGroceryNote.getVisibility() == View.VISIBLE) {
                    // If note text view is visible, toggle to edit mode
                    holder.textGroceryNote.setVisibility(View.GONE);
                    holder.editTextGroceryNote.setVisibility(View.VISIBLE);
                    holder.editTextGroceryNote.setText(grocery.getNote());
                    holder.imageDelete.setVisibility(View.GONE);
                } else {
                    // If edit text is visible, toggle to view mode
                    holder.textGroceryNote.setVisibility(View.VISIBLE);
                    holder.editTextGroceryNote.setVisibility(View.GONE);
                    grocery.setNote(holder.editTextGroceryNote.getText().toString()); // Update note with edited text
                    holder.textGroceryNote.setText(holder.editTextGroceryNote.getText().toString());
                    holder.imageDelete.setVisibility(View.VISIBLE);
                }
            }
        });

        holder.imageDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle delete button click
                ListGrocery.getInstance().removeGrocery(grocery.getName());
                notifyDataSetChanged(); // Notify adapter after removing item
            }
        });


    }

    @Override
    public int getItemCount() {
        return groceries.size();
    }
}


