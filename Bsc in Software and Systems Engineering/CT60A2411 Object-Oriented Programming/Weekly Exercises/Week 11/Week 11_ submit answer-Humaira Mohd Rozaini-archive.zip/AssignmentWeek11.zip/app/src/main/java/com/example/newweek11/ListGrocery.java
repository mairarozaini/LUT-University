    package com.example.newweek11;

    import java.util.ArrayList;
    import java.util.Collections;
    import java.util.Comparator;
    import java.util.List;
    import java.util.Objects;

    public class ListGrocery {
        public ArrayList<Grocery> groceries = new ArrayList<>();

        public static ListGrocery listGrocery = null;

        private ListGrocery(){
        }

        public static ListGrocery getInstance(){
            if(listGrocery == null){
                listGrocery = new ListGrocery();
            }
            return listGrocery;
        }

        public void addGrocery(Grocery grocery){
            groceries.add(grocery);
        }

        public Grocery getGroceryByName(String name){

            for(Grocery grocery: groceries){
                if(Objects.equals(grocery.name, name)){
                    return grocery;
                }
            }
            return null;
        }

        public ArrayList<Grocery> getGroceries(){
            return groceries;
        }

        public void removeGrocery(String name){
                groceries.remove(getGroceryByName(name));
        }

        public void sortGroceriesByAlphabet(){
            Collections.sort(groceries, new Comparator<Grocery>() {
                @Override
                public int compare(Grocery g1, Grocery g2) {
                    return g1.getName().compareToIgnoreCase(g2.getName());
                }
            });

        }

        public void sortGroceriesByTime(){
            Collections.sort(groceries, new Comparator<Grocery>() {
                @Override
                public int compare(Grocery g1, Grocery g2) {
                    return Long.compare(g1.getTimestamp(), g2.getTimestamp());
                }
            });
        }
    }
