package com.example.newweek11;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// This assignment is done through collaborative work with Vera Stojcheva, Padma Voleti, and Melody Zadeh Hosseini

public class MainActivity extends AppCompatActivity {
    public ImageView imageAplhabet,imageTime;
    public Button buttonAdd;

    public static GroceryListAdapter adapter;

    public RecyclerView rvgroceries;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        rvgroceries = findViewById(R.id.rvGroceries);
        buttonAdd = findViewById(R.id.buttonAddNewGrocery);
        imageAplhabet = findViewById(R.id.imageAlphabet);
        imageTime = findViewById(R.id.imageTime);
        adapter = new GroceryListAdapter(this,ListGrocery.getInstance().groceries);
        rvgroceries.setLayoutManager(new LinearLayoutManager(this));
        rvgroceries.setAdapter(adapter);
        Intent intent = new Intent(this,AddGroceryActivity.class);
        buttonAdd.setOnClickListener(v -> startActivity(intent));

        imageAplhabet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListGrocery.getInstance().sortGroceriesByAlphabet();
                adapter.notifyDataSetChanged();
            }
        });
        imageTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListGrocery.getInstance().sortGroceriesByTime();
                adapter.notifyDataSetChanged();
            }
        });
    }
}