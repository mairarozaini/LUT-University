package com.example.week12;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

public class BottomFragment extends Fragment {

    private TextView textImportant;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bottom, container, false);

        textImportant = view.findViewById(R.id.textImportant);
        updateImportantItems(); // Call method to update important items

        return view;
    }

    private void updateImportantItems() {
        List<String> importantItems = ListGrocery.getInstance().getGroceries(); // Get important items list
        StringBuilder builder = new StringBuilder();
        for (String item : importantItems) {
            builder.append(item).append(", ");
        }
    }
}