package com.example.week12;

import java.util.List;

public class Grocery {
    private static Grocery instance;
    private List<String> groceries;

    private Grocery() {}

    public static Grocery getInstance() {
        if (instance == null) {
            instance = new Grocery();
        }
        return instance;
    }

    public List<String> getGroceries() {
        return groceries;
    }

    public void addGrocery(String item) {
        groceries.add(item);
    }
}

