package com.example.week12;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class GroceryListAdapter extends RecyclerView.Adapter<GroceryViewHolder> {
    private List<String> groceries;

    public GroceryListAdapter(List<String> groceries) {
        this.groceries = groceries;
    }

    @NonNull
    @Override
    public GroceryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grocery, parent, false);
        return new GroceryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroceryViewHolder holder, int position) {
        String grocery = groceries.get(position);
        String[] parts = grocery.split(" - ");
        String name = parts[0];
        String note = "";
        if (parts.length > 1) {
            note = parts[1];
        }
        holder.bind(name, note);
    }

    @Override
    public int getItemCount() {
        return groceries.size();
    }
}
