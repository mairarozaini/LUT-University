package com.example.week12;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GroceryViewHolder extends RecyclerView.ViewHolder {
    private TextView textGroceryName;
    private TextView textGroceryNote;

    public GroceryViewHolder(@NonNull View itemView) {
        super(itemView);
        textGroceryName = itemView.findViewById(R.id.textGroceryName);
        textGroceryNote = itemView.findViewById(R.id.textGroceryNote);
    }

    public void bind(String groceryName, String groceryNote) {
        textGroceryName.setText(groceryName);
        textGroceryNote.setText(groceryNote);
    }
}
