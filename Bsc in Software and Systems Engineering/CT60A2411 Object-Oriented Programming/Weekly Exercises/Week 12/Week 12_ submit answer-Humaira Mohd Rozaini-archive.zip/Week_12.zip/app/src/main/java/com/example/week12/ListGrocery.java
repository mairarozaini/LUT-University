package com.example.week12;

import java.util.ArrayList;
import java.util.List;

public class ListGrocery {
    private static ListGrocery instance;
    private List<String> groceries;

    private ListGrocery() {
        groceries = new ArrayList<>();
    }

    public static ListGrocery getInstance() {
        if (instance == null) {
            instance = new ListGrocery();
        }
        return instance;
    }

    public List<String> getGroceries() {
        return groceries;
    }

    public void addGrocery(String item) {
        groceries.add(item);
    }
}
