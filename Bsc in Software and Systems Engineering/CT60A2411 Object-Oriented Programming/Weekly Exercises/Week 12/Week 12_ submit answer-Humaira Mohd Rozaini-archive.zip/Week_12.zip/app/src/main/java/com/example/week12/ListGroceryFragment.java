package com.example.week12;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ListGroceryFragment extends Fragment {

    private RecyclerView rvGroceries;
    private List<String> groceries;
    private GroceryListAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_grocery, container, false);

        rvGroceries = view.findViewById(R.id.rvGroceries);
        groceries = new ArrayList<>();
        adapter = new GroceryListAdapter(groceries);
        rvGroceries.setAdapter(adapter);
        rvGroceries.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        updateGroceryList();
    }

    private void updateGroceryList() {
        List<String> newGroceries = ListGrocery.getInstance().getGroceries();
        groceries.clear();
        groceries.addAll(newGroceries);
        adapter.notifyDataSetChanged();
    }
}
