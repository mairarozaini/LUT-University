package main;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Hedgehog pikseli = new Hedgehog();
        
        int choice;

        do {
            System.out.println("1) Make hedgehog talk, 2) Create new hedgehog, 3) Make hedgehog run, 0) Quit");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("What does hedgehog say?");
                    sc.nextLine();
                    String text = sc.nextLine();
                    pikseli.speak(text);
                    break;
                case 2:
                    System.out.println("What is the name of the hedgehog:");
                    sc.nextLine();
                    String name2 = sc.nextLine();
                    System.out.println("What is the age of the hedgehog:");
                    int age2 = sc.nextInt();
                    pikseli = new Hedgehog(name2, age2);
                    break;
                case 3:
                    System.out.println("How many laps?");
                    int laps = sc.nextInt();
                    pikseli.run(laps);
                    break;
                case 0:
                    System.out.println("Thank you for using the program.");
                    break;
                default:
                    System.out.println("Wrong input value");
                    break;
            }
        } while (choice != 0);

        sc.close();
    } 
}
