package main;

public class Animal {
    String species;
    String name;
    int age;

    public Animal(String species, String name, int age) {
        this.species = species;
        this.name = name;
        this.age = age;
    }
}
