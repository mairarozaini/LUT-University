package main;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please, name the zoo:");
        String zooName = scanner.nextLine();
        Zoo zoo = new Zoo(zooName);

        int choice;
        do {
            printMenu();
            choice = getChoice(scanner);

            switch (choice) {
                case 1:
                    addAnimal(scanner, zoo);
                    break;
                case 2:
                    zoo.listAnimals();
                    break;
                case 3:
                    runAnimals(scanner, zoo);
                    break;
                case 0:
                    System.out.println("Thank you for using the program.");
                    break;
                default:
                    System.out.println("Wrong input value.");
            }

        } while (choice != 0);

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("1) Create a new animal, 2) List all animals, 3) Run animals, 0) End the program");
    }

    private static int getChoice(Scanner scanner) {
        int choice = -1;

        while (choice < 0 || choice > 3) {
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice < 0 || choice > 3) {
                    System.out.println("Wrong input value 1) Create a new animal, 2) List all animals, 3) Run animals, 0) End the program");
                }
            } catch (NumberFormatException e) {
                System.out.println("Wrong input value 1) Create a new animal, 2) List all animals, 3) Run animals, 0) End the program");
            }
        }

        return choice;
    }

    private static void addAnimal(Scanner scanner, Zoo zoo) {
        System.out.println("What species?");
        String species = scanner.nextLine();
        System.out.println("Enter the name of the animal:");
        String name = scanner.nextLine();
        System.out.println("Enter the age of the animal:");
        int age = getValidIntInput(scanner);
        zoo.addAnimal(species, name, age);
    }

    private static void runAnimals(Scanner scanner, Zoo zoo) {
        System.out.println("How many laps?");
        int laps = getValidIntInput(scanner);
        zoo.runAnimals(laps);
    }

    private static int getValidIntInput(Scanner scanner) {
        int input = -1;

        while (input == -1) {
            try {
                input = Integer.parseInt(scanner.nextLine());
                if (input < 0) {
                    System.out.println("Number must be a non-negative integer.");
                    input = -1;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        return input;
    }
}
