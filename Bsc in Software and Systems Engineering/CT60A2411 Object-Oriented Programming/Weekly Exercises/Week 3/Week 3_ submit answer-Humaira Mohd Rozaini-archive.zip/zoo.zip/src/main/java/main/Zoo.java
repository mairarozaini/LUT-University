package main;

import java.util.ArrayList;

public class Zoo {
    String name;
    ArrayList<Animal> animals;

    public Zoo(String name) {
        this.name = name;
        this.animals = new ArrayList<>();
    }

    public void addAnimal(String species, String name, int age) {
        Animal newAnimal = new Animal(species, name, age);
        animals.add(newAnimal);
    }

    public void listAnimals() {
        System.out.println(name + " contains the following animals:");
        for (Animal animal : animals) {
            System.out.println(animal.species + ": " + animal.name + ", " + animal.age + " years");
        }
    }

    public void runAnimals(int laps) {
        for (Animal animal : animals) {
            for (int i = 0; i < laps; i++) {
                System.out.println(animal.name + " runs really fast!");
            }
        }
    }
}

