package main;

import java.util.ArrayList;
import java.util.Scanner;


public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Vehicle> vehicles = new ArrayList<>();

        while (true) {
            System.out.println("1) Create new vehicle, 2) List vehicles 3) Drive cars, 4) Fly planes, 5) Sail the ships, 0) End the program");
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    System.out.println("Which vehicle do you want to build? 1) car, 2) plane, 3) ship");
                    int vehicleType = Integer.parseInt(scanner.nextLine());

                    System.out.println("Who is the manufacturer?");
                        String manufacturer = scanner.nextLine();
                        System.out.println("What is the model of the vehicle?");
                        String model = scanner.nextLine();
                        System.out.println("What is the top speed?");
                        int maxSpeed = Integer.parseInt(scanner.nextLine());

                    if (vehicleType == 1) {
                        vehicles.add(new Car(manufacturer, model, maxSpeed));
                    } else if (vehicleType == 2) {
                        vehicles.add(new Plane(manufacturer, model, maxSpeed));
                    } else if (vehicleType == 3) {
                        vehicles.add(new Ship(manufacturer, model, maxSpeed));
                    }
                    break;

                case 2:

                    for (Vehicle vehicle : vehicles) {
                        System.out.println(vehicle.type + ": " + vehicle.manufacturer + " " + vehicle.model);
                        System.out.println("Engine: " + vehicle.engine.name + " " + vehicle.engine.power + "kW");
                        System.out.println("Top speed: " + vehicle.maxSpeed + "km/h\n");
                    }
                    break;

                case 3:
                    for (Vehicle vehicle : vehicles) {
                        if (vehicle instanceof Car) {
                            ((Car) vehicle).drive();
                        }
                    }
                    break;

                case 4:
                for (Vehicle vehicle : vehicles) {
                    if (vehicle instanceof Plane) {
                        ((Plane) vehicle).fly();
                    }
                }
                    break;

                case 5:
                for (Vehicle vehicle : vehicles) {
                    if (vehicle instanceof Ship) {
                        ((Ship) vehicle).sail();
                    }
                }
                break;

                case 0:
                    System.out.println("Thank you for using the program.");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
