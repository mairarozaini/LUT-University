package main;

public class Car extends Vehicle {
    Car(String manufacturer, String model, int maxSpeed) {
        super("Car", manufacturer, model, maxSpeed);
        this.engine = new Engine("V8", 300);
    }

    void drive() {
        System.out.println(manufacturer + " " + model + " blazing the way forward!");
    }
}
