package main;

public class Plane extends Vehicle {
    Plane(String manufacturer, String model, int maxSpeed) {
        super("Plane", manufacturer, model, maxSpeed);
        this.engine = new Engine("Jet engine", 500);
    }

    void fly() {
        System.out.println(manufacturer + " " + model + " flying to the destination!");
    }
}
