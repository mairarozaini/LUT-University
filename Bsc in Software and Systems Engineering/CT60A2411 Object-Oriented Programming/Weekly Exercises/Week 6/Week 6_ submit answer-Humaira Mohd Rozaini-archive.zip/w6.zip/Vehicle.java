package main;

public class Vehicle {
    String type, manufacturer, model;
    int maxSpeed;
    Engine engine;

    Vehicle(String type, String manufacturer, String model, int maxSpeed) {
        this.type = type;
        this.manufacturer = manufacturer;
        this.model = model;
        this.maxSpeed = maxSpeed;
    }
}
