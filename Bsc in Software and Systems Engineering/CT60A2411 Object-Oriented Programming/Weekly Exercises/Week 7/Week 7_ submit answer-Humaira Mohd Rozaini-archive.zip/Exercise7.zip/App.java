package universityproject;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Gifu gifu = new Gifu();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Gifu!");
        System.out.println("For which university do you want to implement the system?");
        String university = scanner.nextLine();
        //System.out.println("University selected: " + university);

        int choice;
        do {
            System.out.print("1) Create a new course, ");
            System.out.print("2) Create a new student, ");
            System.out.print("3) List the courses, ");
            System.out.print("4) List the students, ");
            System.out.print("5) Add a student to the course, ");
            System.out.print("6) Give the course grades, ");
            System.out.print("7) List the students in the course, ");
            System.out.print("8) List the student's grades, ");
            System.out.print("9) List all grades of all students in the courses, ");
            System.out.println("0) End the program");
            System.out.print(" ");
            choice = Integer.parseInt(scanner.nextLine());
            // choice = scanner.nextInt();
            // scanner.nextLine();
            switch (choice) {
                case 1:
                    Course tempCourse = new Course();
                    System.out.println("Enter the name of the course:");
                    String courseName = scanner.nextLine();
                    tempCourse.setCourseName(courseName);

                    System.out.println("Enter the course ID:");
                    String courseId = scanner.next();
                    tempCourse.setCourseId(courseId);
                    System.out.println("Enter the maximum number of students:");
                    int maxStudents;
                    try {
                        // maxStudents = Integer.parseInt(scanner.next());
                        maxStudents = scanner.nextInt();
                        scanner.nextLine();
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a number.");
                        continue;
                    }
                    tempCourse.setMaxNumberOfStudents(maxStudents);
                    gifu.addCourse(tempCourse);
                    break;
                case 2:
                    Student tempStudent = new Student();
                    System.out.println("Enter the student name:");
                    String name = scanner.nextLine();
                    tempStudent.setName(name);
                    System.out.println("Enter the student number:");
                    String id = scanner.nextLine();
                    tempStudent.setId(id);
                
                    gifu.addStudent(tempStudent);
                    break;
                case 3:
                    //System.out.println("List of courses:");
                    gifu.listCourses();
                    break;
                case 4:
                    //System.out.println("List of students:");
                    gifu.listStudents();
                    break;
                case 5:
                    //System.out.println("Add a student to the course:");
                    addStudentToCourse(gifu,scanner);
                    break;
                case 6:
                    //System.out.println("Give the course grades:");
                    giveCourseGrades(gifu, scanner);
                    break;
                case 7:             
                    //System.out.println("List the students in the course:");
                    listStudentsInCourse(gifu, scanner);
                    break;
                case 8:
                    //System.out.println("List of students's grades,:");
                    for (Enrollment enrollment : gifu.getAllEnrollments()) {
                        List<Student> students = enrollment.getStudents();
                        // Check for the NullPointerException
                        if (students != null) {
                            for (Student tStudent : students) {
                                System.out.print(tStudent + " grade: " + enrollment.getGrade() + "\n");
                            }
                        }
                    }
                    break;
                case 9:
                    //System.out.println("List all grades of all students in the courses:");
                    gifu.listEnrollments();
                    break;
                case 0:
                    System.out.println("Thank you for using the program.");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
        } while (choice != 0);

        scanner.close();
    }
    public static void addStudentToCourse(Gifu gifu, Scanner scanner) {
        gifu.listCourses();
        System.out.println("To which course do you want to enroll a student? Provide the number of the course:");
        int courseNumber;
        try {
            // courseNumber = Integer.parseInt(scanner.next());
            courseNumber = scanner.nextInt();
            scanner.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        Course courseToAdd = gifu.getCourse(courseNumber);

        if (courseToAdd == null) {
            System.out.println("Course not found!");
            return;
        }
        
        gifu.listStudents();
        System.out.println("Which student do you want to enroll? Provide the number of the student:");

        int studentNumber;
        try {
            // studentNumber = Integer.parseInt(scanner.next());
            studentNumber = scanner.nextInt();
            scanner.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        
        Student studentToAdd = gifu.getStudent(studentNumber);

        if (studentToAdd == null) {
            System.out.println("Student not found!");
            return;
        }
        
        gifu.enrollmentStudent(studentToAdd, courseToAdd);
        // System.out.println("Student added to the course successfully.");
    }

    public static void giveCourseGrades(Gifu gifu, Scanner scanner) {
        gifu.listCourses();
        System.out.println("Which course do you want to grade? Provide the number of the course:");
        int courseNumber;
        try {
            // courseNumber = Integer.parseInt(scanner.next());
            courseNumber = scanner.nextInt();
            scanner.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        Course courseTo = gifu.getCourse(courseNumber);

        if (courseTo == null) {
            System.out.println("Course not found!");
            return;
        }
        Enrollment courseEnrol = gifu.getEnrollments(courseTo);
        List<Student> students = courseEnrol.getStudents();
        // Check for the NullPointerException
        int grade;
        if (students != null) {
            for (Student tempStudent : students) {
                System.out.println("Give grade to the student:" + tempStudent);                
                try {
                    // grade = Integer.parseInt(scanner.next());
                    grade = scanner.nextInt();
                    scanner.nextLine();
                    courseEnrol.gradeCourse(grade);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    return;
                }
            }               
        }
    }
    public static void listStudentsInCourse(Gifu gifu, Scanner scanner) {

        gifu.listCourses();
        System.out.println("which course do you want to see the students for? Provide the number of the course:");
        int courseNo;
        try {
            // courseNo = Integer.parseInt(scanner.next());
            courseNo = scanner.nextInt();
            scanner.nextLine();
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        Course courseTo = gifu.getCourse(courseNo);

        if (courseTo == null) {
            System.out.println("Course not found!");
            return;
        }
        
        Enrollment courseEnrol = gifu.getEnrollments(courseTo);
        List<Student> students = courseEnrol.getStudents();
        // Check for the NullPointerException
        if (students != null) {
            for (Student tempStudent : students) {
                System.out.println(tempStudent + " grade:" + courseEnrol.getGrade());
            }
        }
    }
}
