package universityproject;

public class Course implements PrintInfo {
    private int maxNumberOfStudents;
    private String name;
    private String id;

    // Empty Constructor
    public Course() {
        
    }

    // Constructor that takes a Course object as a parameter
    public Course(Course course) {
        this.name = course.getCourseName();
        this.id = course.getCourseId();
        this.maxNumberOfStudents = course.getMaxNumberOfStudents();    
    }

    public String getCourseName() {
        return name;
    }
    public String getCourseId() {
        return id;
    }
    public int getMaxNumberOfStudents() {
        return maxNumberOfStudents;
    }
    public void setCourseId(String courseId) {
        this.id = courseId;

    }
    public void setCourseName(String courseName) {
        this.name = courseName;

    }
    public void setMaxNumberOfStudents(int maxStudents) {
        this.maxNumberOfStudents = maxStudents;

    }
    @Override
    public String toString() {
        return id + " " + name;
    }

    @Override
    public String getInformation() {
        return "Course Id: " + id + "Course Name: " + name;
    }
}

