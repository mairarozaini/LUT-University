package universityproject;

import java.util.List;
import java.util.ArrayList;

public class Enrollment {
    private List<Student> students;
    private Course course;
    private int grade;

    public Enrollment(Course course) {
        this.students = new ArrayList<>();
        this.course = course;
        this.grade = -1; // default grade
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void removeStudent(Student student) {
        students.remove(student);
    }

    public List<Student> getStudents() {
        return students;
    }

    public Course getCourse() {
        return course;
    }

    public int getGrade() {
        return grade;
    }

    public void gradeCourse(int grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(course).append("\n");
        for (Student student : students) {
            sb.append(student);
        }
        sb.append(" Grade: ").append(grade).append("\n");
        return sb.toString();
    }
}