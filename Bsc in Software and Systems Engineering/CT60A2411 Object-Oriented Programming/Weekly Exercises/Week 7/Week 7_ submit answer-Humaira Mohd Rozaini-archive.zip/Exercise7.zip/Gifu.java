package universityproject;

import java.util.ArrayList;
import java.util.List;

interface PrintInfo {
    String getInformation();
}

class Gifu {
    private String University;
    private ArrayList<Course> courses;
    private ArrayList<Student> students;
    private ArrayList<Enrollment> enrollments;

    public Gifu() {
        courses = new ArrayList<>();
        students = new ArrayList<>();
        enrollments = new ArrayList<>();
    }

    public void addCourse(Course newCourse) {
        Course tempCourse = new Course(newCourse);
        courses.add(tempCourse);
    }

    public Course getCourse(int id) {
        // Get course based on the index value, not based on course id
        // Validate selected course index/ number
          if (id < 0 || id >= courses.size()) {
            System.out.println("Invalid course number!!");
            return null;
        }

        if (id >= 0 && id < courses.size()) {
            return courses.get(id);
        } 
        else
        {
            // throw an exception if index is out of bound
            return null; 
        }
    }
    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void listCourses() {
        // list all the courses; in the University
        
        for (int i=0;  i < courses.size(); i++) {
            System.out.println(i + ") " + courses.get(i) );
        }
    }

    public void addStudent(Student newStudent) {
        Student tempStudent = new Student(newStudent);
        students.add(tempStudent);
    }

    public Student getStudent(int id) {
        // Get student based on the index value, not based on the student id
        if (id < 0 || id >= students.size()) {
            System.out.println("Invalid student number!!");
            return null;
        }

        if (id >= 0 && id < students.size()) {
            return students.get(id);
        } 
        else 
        {
            // throw an exception if index is out of bound
            return null; 
        }
    }
    public void listStudents() {
        // list all the Students; in the University
        
        for (int i=0;  i < students.size(); i++) {
            System.out.println(i + ") " + students.get(i) );
        }
    }

    public Enrollment getEnrollments(Course course) {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().equals(course)) {
                return enrollment;
            }
        }
		return null;
    }

  public Enrollment getEnrollments(Student student) {
    for (Enrollment enrollment : enrollments) {
        List<Student> students = enrollment.getStudents();
        // Check for the NullPointerException
        if (students != null) {
            for (Student tempStudent : students) {
                // Comparing student names ignoring case
                if (tempStudent.getName().equalsIgnoreCase(student.getName())) {
                    return enrollment;
                }
            }
        }
    }
    return null;
}
    public void listEnrollments() {
        // list all the Enrollments done so far; in the University
        
        for (int i=0;  i < enrollments.size(); i++) {
            System.out.println(i + ") " + enrollments.get(i));
        }
    }
    public ArrayList<Enrollment> getAllEnrollments() {
       return enrollments;
    }

    public void enrollmentStudent(Student student, Course course) {
        Enrollment enrollment = findEnrollmentForCourse(course);
        if (enrollment == null) {
            enrollment = new Enrollment(course);
            enrollments.add(enrollment);
        }
        enrollment.addStudent(student);
    }
    
    private Enrollment findEnrollmentForCourse(Course course) {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().equals(course)) {
                return enrollment;
            }
        }
        return null;
    }
}
