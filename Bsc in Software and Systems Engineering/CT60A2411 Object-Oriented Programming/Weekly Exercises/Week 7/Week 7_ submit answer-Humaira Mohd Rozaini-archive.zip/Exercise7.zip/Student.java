package universityproject;

public class Student implements PrintInfo {
    private String name;
    private String id;

    public Student(String name) {
        this.name = name;
    }

    // Empty Constructor
    public Student() {
        
    }

    // Constructor that takes a Student object as a parameter
    public Student(Student student) {
        this.name = student.getName();
        this.id = student.getId();   
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return id + " " + name;
    }

    @Override
    public String getInformation() {
        return "Student Name: " + name + "Student Id: " + id;
    }
}