package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonAdd, buttonSub, buttonMul, buttonDiv;
    EditText editTextN1, editTextN2;
    TextView textView;

    int num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAdd = findViewById(R.id.plusButton);
        buttonSub = findViewById(R.id.minusButton);
        buttonMul = findViewById(R.id.multiplyButton);
        buttonDiv = findViewById(R.id.divideButton);
        editTextN1 = findViewById(R.id.editFirstNumber);
        editTextN2 = findViewById(R.id.editSecondNumber);
        textView = findViewById(R.id.textSeeResult);

        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
    }

    public int getIntFromEditText(EditText editText) {
        String input = editText.getText().toString().trim();
        if (input.isEmpty()) {
            Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
            return 0;
        } else {
            return Integer.parseInt(input);
        }
    }

    @Override
    public void onClick(View v) {
        num1 = getIntFromEditText(editTextN1);
        num2 = getIntFromEditText(editTextN2);
        switch (v.getId()) {
            case R.id.plusButton:
                textView.setText(String.valueOf(num1 + num2));
                break;
            case R.id.minusButton:
                textView.setText(String.valueOf(num1 - num2));
                break;
            case R.id.multiplyButton:
                textView.setText(String.valueOf(num1 * num2));
                break;
            case R.id.divideButton:
                if (num2 == 0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                } else {
                    textView.setText(String.valueOf(num1 / num2));
                }
                break;
        }
    }
}
