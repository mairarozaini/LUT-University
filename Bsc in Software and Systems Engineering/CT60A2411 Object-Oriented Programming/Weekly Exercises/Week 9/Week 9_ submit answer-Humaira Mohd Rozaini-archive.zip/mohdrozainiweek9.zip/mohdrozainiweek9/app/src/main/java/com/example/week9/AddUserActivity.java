package com.example.week9;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.example.week9.User;
import com.example.week9.UserStorage;

public class AddUserActivity extends AppCompatActivity {
    private EditText editFirstName;
    private EditText editLastName;
    private EditText editEmail;
    private RadioGroup radioDegreeProgram;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        // Initialize views
        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
        editEmail = findViewById(R.id.editEmail);
        radioDegreeProgram = findViewById(R.id.radioDegreeProgram);

        Button addUserButton = findViewById(R.id.addUserButton);
        addUserButton.setOnClickListener(view -> {
            String firstName = editFirstName.getText().toString().trim();
            String lastName = editLastName.getText().toString().trim();
            String email = editEmail.getText().toString().trim();

            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                int selectedRadioButtonId = radioDegreeProgram.getCheckedRadioButtonId();
                if (selectedRadioButtonId == -1) {
                    Toast.makeText(this, "Please select a degree program", Toast.LENGTH_SHORT).show();
                } else {
                    RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
                    String degreeProgram = selectedRadioButton.getText().toString();

                    User user = new User(firstName, lastName, email, degreeProgram);
                    UserStorage.getInstance().addUser(user);

                    Toast.makeText(this, "User added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}
