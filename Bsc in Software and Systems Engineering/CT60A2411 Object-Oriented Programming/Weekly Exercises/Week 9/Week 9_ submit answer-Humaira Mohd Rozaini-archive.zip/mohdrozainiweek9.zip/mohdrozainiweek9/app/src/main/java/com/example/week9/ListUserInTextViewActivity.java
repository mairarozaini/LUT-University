package com.example.week9;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ListUserInTextViewActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_user_in_text_view);

        TextView textViewSavedUsers = findViewById(R.id.textViewSavedUsers);
        List<User> users = UserStorage.getInstance().getUsers();

        StringBuilder stringBuilder = new StringBuilder();
        for (User user : users) {
            stringBuilder.append("Name: ").append(user.getFirstName()).append(" ").append(user.getLastName())
                    .append("\nEmail: ").append(user.getEmail())
                    .append("\nDegree Program: ").append(user.getDegreeProgram())
                    .append("\n----------------------------------------\n");
        }
        textViewSavedUsers.setText(stringBuilder.toString());
    }
}

