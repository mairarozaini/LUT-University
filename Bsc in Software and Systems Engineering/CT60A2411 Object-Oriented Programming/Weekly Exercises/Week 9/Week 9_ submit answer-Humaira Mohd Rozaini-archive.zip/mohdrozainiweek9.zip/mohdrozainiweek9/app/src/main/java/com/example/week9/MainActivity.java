package com.example.week9;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addUserButton = findViewById(R.id.addUserButton);
        Button listUserButton = findViewById(R.id.listUserButton);

        addUserButton.setOnClickListener(v -> openAddUserActivity());
        listUserButton.setOnClickListener(v -> openListUserActivity());
    }

    private void openAddUserActivity() {
        startActivity(new Intent(this, AddUserActivity.class));
    }

    private void openListUserActivity() {
        startActivity(new Intent(this, ListUserInTextViewActivity.class));
    }
}
